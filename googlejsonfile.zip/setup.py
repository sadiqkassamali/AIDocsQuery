from setuptools import setup

setup(
    name='dogtags',
    version='1.0',
    packages=[''],
    url='',
    license='Free',
    author='Sadiq',
    author_email='Sadiqkassamali@gmail.com',
    description='DocTags'
)
